#奇异值分解(SVD)可以简化数据，进行隐性语义分析
#奇异值分解惯例，与PCA一样，中间奇异值(特征值)矩阵的奇异值(特征值)按照从大到小顺序排列
#————————————基于协同过滤的推荐引擎————————————————————
#协同过滤方法计算相似度，其并不关心物品的描述属性，而是严格按照许多用户的观点来计算相似度
#用户对物品评分构成矩阵，可以计算物品相似度，也可以计算用户相似度
#用户数远大于物品数时，倾向于基于物品计算相似度
from numpy import *
def euclidsim(a,b):
    return 1/(1+linalg.norm(a-b))  #欧式距离，归一化到0至1
def pearson(a,b):
    if len(a)<3:
        return 1.0
    else:
        return 0.5+0.5*corrcoef(a,b,rowvar = 0)[0][1]  #归一化到0至1
def cosim(a,b):
    num = float(a.T*b)
    normal = linalg.norm(a)*linalg.norm(b)
    return 0.5+0.5*(num/normal)
#制作一个推荐系统
def stand(datamat,user,sim,item):#用于计算用户对未评分物品的评分,输入为用户编号，相似度计算方法，物品编号
    n = shape(datamat)[1]  #物品个数
    simtotal = 0.0
    ratsimtotal = 0.0
    for j in range(n):
        userrate = datamat[user,j]
        if userrate == 0:  #如果该目标用户没对这个物品评分，则跳过这个物品
            continue
        overlap = nonzero(logical_and(datamat[:,item].A>0,datamat[:,j].A>0))[0] #寻找出两个物品中用户评分均不为0的用户编号位置
        if len(overlap) == 0:
            similarity = 0
        else:
            similarity = sim(datamat[overlap,item],datamat[overlap,j])
        simtotal += similarity  #累加目标用户评分不为0的物品与目标物品的相似度作为总相似度
        ratsimtotal += similarity*userrate  #在上述基础上再乘以对应的目标用户的评分，相似度越高，评分越高，对应物品评分越高
    if simtotal == 0:
        return 0
    else:
        return ratsimtotal/simtotal  #归一化输出
def recommend(datamat,user,N = 3,sim = cosim,estmethod = stand): #推荐最高N个结果
    unrated = nonzero(datamat[user,:].A==0)[1]  #找出未评分的物品
    if len(unrated) == 0:
        print('everything has been rated')
    scores = []
    for item in unrated:
        escore = estmethod(datamat,user,sim,item)
        scores.append((item,escore))
    return sorted(scores,key = lambda x:x[1],reverse = True)[:N]
mymat = mat([[4,4,0,2,2],[4,0,0,3,3],[4,0,0,1,1],[1,1,1,2,0],[2,2,2,0,0],[1,1,1,0,0],[5,5,5,0,0]])
#利用SVD再提高推荐效果
def loadExData2():  #面对一个相对稀疏的评分矩阵时，利用SVD将矩阵投影至低维度的空间
    return[[0, 0, 0, 0, 0, 4, 0, 0, 0, 0, 5],
           [0, 0, 0, 3, 0, 4, 0, 0, 0, 0, 3],
           [0, 0, 0, 0, 4, 0, 0, 1, 0, 4, 0],
           [3, 3, 4, 0, 0, 0, 0, 2, 2, 0, 0],
           [5, 4, 5, 0, 0, 0, 0, 5, 5, 0, 0],
           [0, 0, 0, 0, 5, 0, 1, 0, 0, 5, 0],
           [4, 3, 4, 0, 0, 0, 0, 5, 5, 0, 1],
           [0, 0, 0, 4, 0, 4, 0, 0, 0, 0, 4],
           [0, 0, 0, 2, 0, 2, 5, 0, 0, 1, 2],
           [0, 0, 0, 0, 5, 0, 0, 0, 0, 4, 0],
           [1, 0, 0, 0, 0, 0, 0, 1, 2, 0, 0]]
mymat2 = mat(loadExData2())
u,simga,vt = linalg.svd(mymat)
def svdest(datamat,user,sim,item):
    n = shape(datamat)[1]
    simtotal = 0.0
    ratsimtotal = 0.0
    u,sigma,vt = linalg.svd(datamat)
    sig4 = mat(eye(4)*sigma[:4]) #选前4个特征
    formeditem = datamat.T*u[:,:4]*sig4.I   #降维，此式子等价于vt[:4,:].T，行表示各个物品
    for j in range(n):
        userrate = datamat[user,j]  #计算真实用户评分
        if userrate == 0 or j == item:
            continue
        similarity = sim(formeditem[j,:].T,formeditem[item,:].T)  #svd解决了稀疏的问题，因此不用选取两者评分都不等于0的数据，可以直接求解
        simtotal += similarity
        ratsimtotal += similarity*userrate
    if simtotal == 0:
        return 0
    else:
        return ratsimtotal/simtotal
#q = recommend(mymat2,0,estmethod = svdest)
#——————————————————图像压缩的例子————————————————————
def printimg(inmat,thresh = 0.8):  #阈值默认0.8
    for i in range(32):
        for j in range(32):
            if inmat[i,j]>thresh:
                print('%2d'%1,end = '')
            else:
                print('%2d'%0,end = '')
        print('')
def img(numsvd = 3,thresh = 0.8):
    my = []
    for line in open('F:/机器学习实战/machinelearninginaction/Ch14/0_5.txt','r').readlines():
        newrow = []
        for i in range(32):
            newrow.append(int(line[i]))
        my.append(newrow)
    my = mat(my)
    print('————————————————original———————————————————')
    printimg(my,thresh)
    u,sigma,vt = linalg.svd(my)
    sig = mat(zeros((numsvd,numsvd)))
    for k in range(numsvd):
        sig[k,k] = sigma[k]
    mynew = u[:,:numsvd]*sig*vt[:numsvd,:]
    print('—————————————————svd————————————————————')
    printimg(mynew,thresh)   #原来要1024个数，现在是32*2 2*2 2*32矩阵构成的，只要64+2+64=130个数，压缩效率达到10倍，且可以精确画出图形
    return None
img()
                
            
            
        


    
        
    
    



