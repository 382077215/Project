import numpy as np
import matplotlib.pyplot as plt
def loaddata(filename,sep = '\t'):
    f = open(filename,'r')
    string = [line.strip().split(sep) for line in f.readlines()]
    data = [list(map(float,line)) for line in string]
    return np.mat(data)
def pca(data,topfeat = 9999999):  #默认提取前9999999个最大特征值(若不到就取所有的)
    meanval = data.mean(axis = 0)  #(n*d)
    meanremove = data - meanval  #每一行减去均值向量去均值(中心化)
    covmat = np.cov(meanremove,rowvar = 0)#求协方差矩阵(中心化后协方差矩阵等价于X*X',rowvar=0表示行是样本，列是变量[注意，是对变量进行协方差矩阵])
    global outeigval
    eigval,eigvec = np.linalg.eig(np.mat(covmat))
    eigvalind = np.argsort(eigval)
    outeigval = sorted(eigval,reverse = True)
    eigvalind = eigvalind[:-(topfeat+1):-1]  #选取最大的topfeat个，这样切片可以包含最后一个
    anseigvec = eigvec[:,eigvalind]  #选取特征向量,列是特征向量
    lowdatamat = meanremove*anseigvec  #降维结果(n*d*d*d')
    remat = lowdatamat*anseigvec.T+meanval  #将降维结果再投影回原来的空间(重构，结果应该与原来的数据很接近)
    return lowdatamat,remat
#————————————————————————————————————————测试——————————————————————————————————————————————
data1 = loaddata('F:/机器学习实战/machinelearninginaction/Ch13/testSet.txt')
low,rebuild = pca(data1,1)
#————————————————————————————————————————测试——————————————————————————————————————————————
def replacenan():
    datamat = loaddata('F:/机器学习实战/machinelearninginaction/Ch13/secom.data',' ')
    numfea = np.shape(datamat)[1]
    for i in range(numfea):
        meanval = np.mean(datamat[np.nonzero(~np.isnan(datamat[:,i].A))[0],i])  #对每一列不包含缺失值的数据求平均,~相当于非了一下
        datamat[np.nonzero(np.isnan(datamat[:,i].A))[0],i] = meanval
    return datamat
data2 = replacenan()
low1,rebuild2 = pca(data2)
fig = plt.figure()
ax = fig.add_subplot(111)
ax.plot([i for i in range(20)],outeigval[:20])
ax.set_xticks([0,5,10,15,20])
plt.show() #碎石图
