import numpy as np
import matplotlib.pyplot as plt
def loaddata(filename):
    numfea = len(open(filename,'r').readline().split('\t')) - 1
    datamat = []
    labelmat = []
    f = open(filename,'r')
    for line in f.readlines():
        linearr = []
        curline = line.strip().split('\t')
        for i in range(numfea):
            linearr.append(float(curline[i]))
        datamat.append(linearr)
        labelmat.append(float(curline[-1]))
    return datamat,labelmat
def reger(x,y):
    xmat = np.mat(x)
    ymat = np.mat(y)
    xtx = xmat.T*xmat
    if np.linalg.det(xtx)==0:
        print('error')
        return None
    ws = xtx.I*(xmat.T*ymat.T)
    return ws
'''#—————————————————————————————————————测试————————————————————————————————————————————————
x,y = loaddata('F:/机器学习实战/machinelearninginaction/Ch08/ex0.txt')
ws = reger(x,y)
xmat = np.mat(x)
ymat = np.mat(y)
yhat = xmat*ws
corr = np.corrcoef(yhat.T,ymat)  #计算时保证两个都是行向量
#—————————————————————————————————————测试————————————————————————————————————————————————'''
'''
局部加权线性回归
w = (X'WX).I*X'WY       其中W是一个矩阵(对角矩阵)    相当于给每一个样本赋一个权重来训练
W(i,i) = exp(-||xi-x||^2/(2*k*k))  相当于待预测点x离xi越近，xi的权重就越大，每给一个x，可以计算W，估计出系数，从而得到对应的y
w(i,i)相当于一个核，这个核越小(k越小)，模型的复杂度就越大！！！！！！！
'''
def weightreger(test,x,y,k = 1.0):
    xmat = np.mat(x)
    ymat = np.mat(y)
    m = np.shape(xmat)[0]
    weight = np.mat(np.eye(m))   #初始为单位矩阵
    for i in range(m):
        diff = test - xmat[i,:]
        weight[i,i] = np.exp(diff*diff.T/(-2*k*k))
    xtx = xmat.T*(weight*xmat)
    if np.linalg.det(xtx)==0:
        print('error')
        return None
    ws = xtx.I*(xmat.T*(weight*ymat.T))
    return test*ws
def preweightreger(testdata,x,y,k = 1.0):     #局部加权线性回归的预测函数
    m = np.shape(testdata)[0]
    yhat = np.zeros((m,1))
    for i in range(m):
        yhat[i] = weightreger(testdata[i,:],x,y,k)
    return yhat
'''#—————————————————————————————————————测试————————————————————————————————————————————————
x,y = loaddata('F:/机器学习实战/machinelearninginaction/Ch08/ex0.txt')
xmat = np.mat(x)
ymat = np.mat(y)
ws = weightreger(xmat[0,:],x,y,k = 1.0)
yhat = preweightreger(xmat,x,y,k = 1.0)
error = (np.mat(yhat)-ymat.T).T*(np.mat(yhat)-ymat.T)
#—————————————————————————————————————测试————————————————————————————————————————————————'''
def ridgereger(xmat,ymat,lam = 0.2): #岭估计
    xtx = xmat.T*xmat
    temp = xtx+np.mat(np.eye(np.shape(xmat)[1]))*lam
    if np.linalg.det(temp) ==0 :
        print('error')
    ws = temp.I*(xmat.T*ymat)
    return ws
def ridgetest(x,y):  #求最优的lam
    xmat = np.mat(x)
    ymat = np.mat(y).T
    ymean = ymat.mean(axis = 0)
    xmean = xmat.mean(axis = 0)
    xvar = np.var(xmat,axis = 0)  #求每一列特征的方差
    ymat = ymat - ymean
    xmat = (xmat-xmean)/xvar  #归一化
    num = 30  #遍历30个lam
    wmat = np.mat(np.zeros((num,np.shape(xmat)[1])))
    for i in range(num):
        ws = ridgereger(xmat,ymat,np.exp(i-10))
        wmat[i,:] = ws.T
    return wmat
'''#—————————————————————————————————————测试————————————————————————————————————————————————
x,y = loaddata('F:/机器学习实战/machinelearninginaction/Ch08/abalone.txt')
rw = ridgetest(x,y)
fig = plt.figure()
ax = fig.add_subplot(111)
ax.plot(rw)  #矩阵一列为一个变量画一条线
#横坐标表示lam,纵坐标表示系数，体现了系数随lam的变化
plt.show()
#—————————————————————————————————————测试————————————————————————————————————————————————'''
'''
向前逐步回归，效果类似于lasso(添加了L1正则化，可以将一些系数衰减至0，有筛选特征的功能)
1.数据标准化 2.设置最小误差为无穷大 3.对于每一个特征，增大或缩小系数，得到一个新的系数向量w，如误差小于最小误差则更新 4.重复至迭代结束
'''
def stepreger(x,y,epi = 0.01,numiter = 100):
    xmat = np.mat(x)
    ymat = np.mat(y).T
    ymean = ymat.mean(axis = 0)
    ymat = ymat - ymean
    xmean = xmat.mean(axis = 0)
    xvar = np.var(xmat,axis = 0)
    xmat = (xmat-xmean)/xvar
    m,n = np.shape(xmat)
    returnmat = np.mat(np.zeros((numiter,n)))
    ws = np.mat(np.zeros((n,1)))  #初始化系数
    wstest = ws.copy()  #初始化
    wsmax = ws.copy()  #初始化
    for i in range(numiter): #迭代次数
        lowesterror = np.inf
        for j in range(n):   #变量每个特征
            for sign in [-1,1]:  #每个特征对应系数的加减
                wstest = ws.copy()
                wstest[j] += sign*epi
                ytest = xmat*wstest
                error = (ymat-ytest).T*(ymat-ytest)
                if error<lowesterror:
                    lowesterror = error
                    wsmax = wstest
        ws = wsmax.copy()
        returnmat[i,:] = ws.T
    return returnmat  #返回系数矩阵，其中记录每一次迭代之后的系数，一行为一次迭代
'''#—————————————————————————————————————测试————————————————————————————————————————————————
x,y = loaddata('F:/机器学习实战/machinelearninginaction/Ch08/abalone.txt')
ans = stepreger(x,y)
#—————————————————————————————————————测试————————————————————————————————————————————————'''
def crossvalid(x,y,num = 10): #交叉验证,默认10折
    m = len(y)
    indexlist = list(range(m))
    errormat = np.mat(np.zeros((num,30)))
    for i in range(num):
        trainx = []
        trainy = []
        testx = []
        testy = []
        np.random.shuffle(indexlist)  #对indexlist随机混乱排序，10折交叉验证，每一次都混乱排序一次
        for j in range(m):   
            if j<m*0.9:
                trainx.append(x[indexlist[j]])   #90%作为训练集,10%作为测试集
                trainy.append(y[indexlist[j]])
            else:
                testx.append(x[indexlist[j]])
                testy.append(y[indexlist[j]])
        ws = ridgetest(trainx,trainy)  #30*d的矩阵
        for k in range(30):
            mattestx = np.mat(testx)
            mattrainx = np.mat(trainx)
            meantrain = mattrainx.mean(axis = 0)
            vartrain = mattrainx.var(axis = 0)
            mattestx = (mattestx-meantrain)/vartrain
            ypre = mattestx*ws[k,:].T+np.mat(trainy).T.mean(axis = 0)
            errormat[i,k] = (np.mat(testy).T-ypre).T*(np.mat(testy).T-ypre)  #第i次迭代(交叉验证)，在岭估计lam取值为第k个时候的误差
    meanerror = errormat.mean(axis = 0)
    minindex = np.argmin(meanerror)
    bestws = ws[minindex,:]  #由于是交叉验证，确定lam取第几个时，哪一个训练样本训练出来的系数都是可以使用的
    xmat = np.mat(x)
    ymat = np.mat(y).T
    meanx = xmat.mean(axis = 0)
    varx = xmat.var(axis = 0)
    ymean = ymat.mean(axis = 0)
    ans = bestws/varx
    return ans
#—————————————————————————————————————测试————————————————————————————————————————————————
x,y = loaddata('F:/机器学习实战/machinelearninginaction/Ch08/abalone.txt')
ans = crossvalid(x,y)  #利用十折交叉验证，选取30个lam中最优的那个lam
#—————————————————————————————————————测试————————————————————————————————————————————————

        
        
    


    

    
