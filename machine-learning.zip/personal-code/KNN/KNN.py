import numpy as np
import operator as op
from os import listdir
import matplotlib.pyplot as plt
def createdata():
    group = np.array([[1,1.1],[1,1],[0,0],[0,0.1]])
    labels = ['a','a','b','b']
    return group,labels
def knnclassify(test,data,label,k):
    m = np.shape(data)[0]
    testmat = (np.tile(test,(m,1))-data)**2  #np.tile将测试数据复制为m行一列的，相当于m个，每一个都是test
    distnonsq = testmat.sum(axis = 1)  #按照列加，相当于把一行所有数据加起来
    dist = distnonsq**0.5
    distindex = dist.argsort()
    classcount = {}
    for i in range(k):
        votelabel = label[distindex[i]]
        if votelabel in classcount.keys():
            classcount[votelabel] += 1
        else:
            classcount[votelabel] = 1
    classcount = sorted(classcount.items(),key = op.itemgetter(1),reverse = True)  #按照字典中item的第二个元素从大到小排序
    return classcount[0][0]
def filemat2(path):  #提取约会数据函数,array格式输出
    f = open(path,'r')
    wholelines = f.readlines()
    num = len(wholelines)
    returnmat = np.zeros((num,3))
    classlabel = []
    index = 0
    for line in wholelines:
        line = line.strip()
        line = line.split('\t')
        returnmat[index,:] = line[0:3]
        classlabel.append(line[-1])
        index += 1
    return returnmat,classlabel
def norm(data):   #定义归一化函数,data为array格式
    minvalue = data.min(axis = 0)
    maxvalue = data.max(axis = 0)
    ranges = maxvalue - minvalue
    m = np.shape(data)[0]
    normdata = data - np.tile(minvalue,(m,1))
    normdata = normdata/np.tile(ranges,(m,1))
    return normdata,ranges,minvalue
def datingtest(): #约会测试函数
    ratio = 0.1
    global datingdata
    datingdata,datinglabel = filemat2('F:/机器学习实战/machinelearninginaction/Ch02/datingTestSet.txt')
    normdata,ranges,minvalue = norm(datingdata)
    m = np.shape(normdata)[0]
    numtest = int(m*ratio)   #前百分之十的数据作为测试数据
    errorcount = 0
    for i in range(numtest):
        result = knnclassify(normdata[i,:],normdata[numtest:m,:],datinglabel[numtest:m],3)
        if result != datinglabel[i]:
            errorcount += 1
    print(errorcount/numtest)
    return None
#datingtest()
def imgvector(file):  #读取图像数据
    returnvect = np.zeros((1,1024))
    f = open(file,'r')
    for i in range(32):
        line = f.readline()
        for j in range(32):
            returnvect[0,32*i+j] = line[j]
    return returnvect
def handnumber():
    hnlabel = []
    trainlist = listdir('F:/机器学习实战/machinelearninginaction/Ch02/trainingDigits')
    m = len(trainlist)
    traindata = np.zeros((m,1024))
    for i in range(m):
        filenamestr = trainlist[i]
        filename = filenamestr.split('.')[0]
        classnum = int(filename.split('_')[0])
        hnlabel.append(classnum)
        traindata[i,:] = imgvector('F:/机器学习实战/machinelearninginaction/Ch02/trainingDigits/'+filenamestr)
    testlist = listdir('F:/机器学习实战/machinelearninginaction/Ch02/testDigits')
    n = len(testlist)
    errorcount = 1
    for i in range(n):
        filenamestr = testlist[i]
        filename = filenamestr.split('.')[0]
        classnum = int(filename.split('_')[0])
        testdata = imgvector('F:/机器学习实战/machinelearninginaction/Ch02/testDigits/'+filenamestr)
        result = knnclassify(testdata,traindata,hnlabel,3)
        if result != classnum:
            errorcount += 1
    print(errorcount/n)
    return None
handnumber()



    
    
    
