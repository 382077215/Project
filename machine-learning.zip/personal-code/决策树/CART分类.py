from math import log
import numpy as np
import re
filename = 'F:/机器学习实战/machinelearninginaction/Ch03/lenses.txt'
def loaddata(filename):
    dataset = []
    fr = open(filename,'r')
    for line in fr.readlines():
        curline = line.strip().split('\t')
        dataset.append(curline)
    return dataset
def splitdataset(dataset,axis,value):
    data1 = []
    data2 = []
    for i in dataset:
        datatemp = i[:axis] + i[axis+1:]
        if i[axis] == value:
            data1.append(datatemp)
        else:
            data2.append(datatemp)
    return data1,data2
def classgini(dataset):
    s = 0.0
    samplenum = len(dataset)
    label = {}
    for i in dataset:
        temp = i[-1]
        if temp not in label.keys():  #不在就创建一个键
            label[temp] = 0
        label[temp] += 1  #在对应键的数目上加1
    for key in label.keys():
        prob = float(label[key])/samplenum
        s += prob*prob
    gini = 1-s
    return gini
def choose(dataset):
    bestgini = np.inf
    bestvalue = 0
    bestfeature = 0
    numfeatures = len(dataset[0])-1
    for i in range(numfeatures):
        feature = [example[i] for example in dataset]
        uniquefeature = set(feature)
        for j in uniquefeature:
            data1,data2 = splitdataset(dataset,i,j)
            newgini = (len(data1)/len(dataset))*classgini(data1)+(len(data2)/len(dataset))*classgini(data2)
            if newgini<bestgini:
                bestvalue = j
                bestfeature = i
                bestgini = newgini
    return bestfeature,bestvalue
def majorclass(classlist):
    classcount = {}
    for vote in classlist:
        if vote not in classcount.keys():
            classcount[vote] = 0
            classcount[vote] += 1
    sortclass = sorted(classcount.items(),key = lambda x:x[1],reverse = True)
    return sortclass[0][0]
def createtree(dataset,labels):        #!!!!!!!!!!!!!!!!!!!!这边构造出的决策树有略微的随机性!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    classlist = [example[-1] for example in dataset]  #列出每个样本所属类别
    if classlist.count(classlist[0]) == len(classlist): #都是一类则直接结束
        return classlist[0]
    if len(dataset[0]) == 1:  #所有特征已经遍历完，取多数为类
        return majorclass(classlist)
    bestfeature,bestvalue = choose(dataset)
    bestfeaturelabel = labels[bestfeature]
    tree = {(bestfeaturelabel+'_'+str(bestvalue)):{}}
    del(labels[bestfeature]) #用过一次的特征就删去
    data1,data2 = splitdataset(dataset,bestfeature,bestvalue)
    sublabels = labels[:]
    tree[(bestfeaturelabel+'_'+str(bestvalue))]['yes'] = createtree(data1,sublabels)
    sublabels = labels[:]  #这里注意递归顺序，有可能上面的递归函数调用已经改变了sublabels
                            #所以需要再定义一下，防止bug
    tree[(bestfeaturelabel+'_'+str(bestvalue))]['no'] = createtree(data2,sublabels)
    return tree
def classify(tree,labels,test):
    firststr = list(tree.keys())[0]
    secondist = tree[firststr]
    featureindex = labels.index(re.findall('([a-z]*)_',firststr)[0])
    if test[featureindex] == re.findall('_([a-z]*)',firststr)[0]:
        if type(secondist['yes']).__name__ == 'dict':
            classlabel = classify(secondist['yes'],labels,test)
        else:
            classlabel = secondist['yes']
    else:
        if type(secondist['no']).__name__ == 'dict':
            classlabel = classify(secondist['no'],labels,test)
        else:
            classlabel = secondist['no']
    return classlabel
#------------------------------测试样例---------------------------------
dataset = loaddata(filename)
traindataset = dataset[0:6]+dataset[8:14]+dataset[16:22]
testdataset = dataset[6:8]+dataset[14:16]+dataset[22:24]
featurelabels = ['age','symptom','astigmatic','tear']
finaltree = createtree(traindataset,featurelabels)
featurelabels = ['age','symptom','astigmatic','tear']
def pre(finaltree,testdataset):
    predict = []
    initial = [i[-1] for i in testdataset]
    for i in testdataset:
        predict.append(classify(finaltree,featurelabels,i))
    pcorrect = sum([1 if predict[i]==initial[i] else 0 for i in range(len(predict))])/len(predict)
    return pcorrect
p = pre(finaltree,testdataset)
#------------------------------测试样例----------------------------------
#-----------------------------剪枝---------------------------------------
def istree(obj):
    return (type(obj).__name__ == 'dict')
def prune(tree,testdata,traindata,labels):
    if len(testdata) == 0:  
        return tree               #这种情况下默认原来训练出的树在没有测试集验证的情况下是不过拟合的,没有测试数据就不剪枝
        #return majorclass([example[-1] for example in traindata])    #这种情况下默认原来的树就是过拟合的，没有测试数据时会直接将整个树或者子树全部剪去
    firststr = list(tree.keys())[0]
    feature = re.findall('([a-z]*)_',firststr)[0]
    value = re.findall('_([a-z]*)',firststr)[0]
    if (istree(tree[firststr]['yes'])) or (istree(tree[firststr]['no'])):                               #!!!!!!!!!!!!!!!!!!!!这里删去已用特征的写法问题也不大!!!!!!!!!!!!!!!!!!!!!!!!
        testdata1,testdata2 = splitdataset(testdata,labels.index(feature),value)       #!!!!!!!!!!!!!!!!!这里的切分数据集应该重写，主要是由于数据集以及特征标签会越剪越小导致不稳定!!!!!!!!!!!!!!!!!!!!!
        traindata1,traindata2 = splitdataset(traindata,labels.index(feature),value)  #!!!!!!!!!!!!!!!!写为分割后不删去已用特征的数据集，会使得递归更稳定!!!!!!!!!!!!!!!!!!!!!!!
        del(labels[labels.index(feature)])                                                               #!!!!!!!!!!!!!!!!剪枝这里的labels应该不删已用特征去会使得递归更稳定!!!!!!!!!!!!!!!!
    if (istree(tree[firststr]['yes'])):
        sublabels = labels[:]
        tree[firststr]['yes'] = prune(tree[firststr]['yes'],testdata1,traindata1,sublabels)
    if (istree(tree[firststr]['no'])):
        sublabels = labels[:]
        tree[firststr]['no'] = prune(tree[firststr]['no'],testdata2,traindata2,sublabels)
    if not istree(tree[firststr]['yes']) and not istree(tree[firststr]['no']):
        errornomerge = pre(tree,testdata)
        temp = [i[-1] for i in traindata]
        templabel = majorclass(temp)
        errormerge = sum([1 if i[-1] == templabel else 0 for i in testdata])/len(testdata)
        if errormerge>errornomerge:   #剪枝后精度跟高，就剪枝
            print('merge')
            return templabel
        else:
            return tree
    else:
        return tree
#测试剪枝结果[注:由于决策树很小，这里没有进行剪枝，剪枝前后的决策树应该一样]
#print(finaltree)  #比较一下
#prunetree = prune(finaltree,testdataset,traindataset,featurelabels)
#print(prunetree)  #比较一下
#-----------------------------剪枝---------------------------------------
#----------------------------交叉验证------------------------------------
crossans = []
crossans2 = []
for j in range(24):
    if (j+18)<24:
        crosstraindata = dataset[j:j+18]
        crosstestdata = dataset[j+18:24]+dataset[0:j]
    else:
        crosstraindata = dataset[j:24]+dataset[0:j-6]
        crosstestdata = dataset[j-6:j]
    crossfeaturelabels = ['age','symptom','astigmatic','tear']
    crossfinaltree = createtree(crosstraindata,crossfeaturelabels)  #构造决策树
    crossfeaturelabels = ['age','symptom','astigmatic','tear']
    crossans.append(pre(crossfinaltree,crosstestdata))
    crossprunetree = prune(crossfinaltree,crosstestdata,crosstraindata,crossfeaturelabels)
    crossans2.append(pre(crossprunetree,crosstestdata))
print(sum(crossans)/len(crossans))
print(sum(crossans2)/len(crossans2))
        
        
        
    
    
    
        
    
    
                
            
            
        
    

        
        
            
        
        
    

            
        
    
    
    
