import numpy as np
filename = 'F:/机器学习实战/machinelearninginaction/Ch09/ex2.txt'
filename1 = 'F:/机器学习实战/machinelearninginaction/Ch09/ex2test.txt'
filename2 = 'F:/机器学习实战/machinelearninginaction/Ch09/exp2.txt'
def loaddata(filename):
    datamat = []
    fr = open(filename,'r')
    for line in fr.readlines():
        curline = line.strip().split('\t')
        ansline = list(map(float,curline)) #将list中元素变为浮点数
        datamat.append(ansline)
    return np.mat(datamat)  #转化为矩阵形式
datamat = loaddata(filename)
datamat2 = loaddata(filename2)
datatest = loaddata(filename1)
def splitdataset(datamat,feature,value):
    mat0 = datamat[np.nonzero(datamat[:,feature]>value)[0],:]  #nonzero返回非零元素坐标，这边因为是连续变量，所以用过的变量在子回归中依旧可以使用 
    mat1 = datamat[np.nonzero(datamat[:,feature]<=value)[0],:]
    return mat0,mat1
def regleaf(datamat):
    return np.mean(datamat[:,-1])   #利用均值来作为回归的值
def regerror(datamat):    #利用平方和来作为误差项
    return np.var(datamat[:,-1])*np.shape(datamat[:,-1])[0]
def choosebestsplit(datamat,leaftype = regleaf,errtype = regerror,ops = (1,4)):
    tols = ops[0]  #为用户设定的参数，tols为最小误差下降值，toln为最小切分样本数目
    toln = ops[1]
    if len(set(datamat[:,-1].T.tolist()[0])) == 1:  #如果该节点上所有值都一样，返回None,值就是均值
        return None,leaftype(datamat)
    m,n = np.shape(datamat)
    s = errtype(datamat)
    bests = np.inf      #最优分割误差先设置为正无穷
    bestindex = 0
    bestvalue = 0
    for findex in range(n-1): #遍历特征
        for splitvalue in set(datamat[:,findex].T.tolist()[0]):  #遍历值找切分点
            mat0,mat1 = splitdataset(datamat,findex,splitvalue)
            if (np.shape(mat0)[0]<toln) or (np.shape(mat1)[0]<toln): #如果某个切分后一部分数据小于最小样本数，则不在这里切分，跳过此次循环
                continue
            news = errtype(mat0) + errtype(mat1)   #计算分隔后当前子树的误差
            if news<bests:
                bestindex = findex
                bestvalue = splitvalue
                bests = news
    if (s-bests)<tols:  #误差减少量小于阈值，依旧不再进行划分
        return None,leaftype(datamat)
    mat0,mat1 = splitdataset(datamat,bestindex,bestvalue)    #防止所有情况样本都不够，循环内的语句没有执行，而直接返回0,inf产生bug
    if (np.shape(mat0)[0]<toln) or (np.shape(mat1)[0]<toln):#防止所有情况样本都不够，循环内的语句没有执行，而直接返回0,inf产生bug
        return None,leaftype(datamat)                                   #防止所有情况样本都不够，循环内的语句没有执行，而直接返回0,inf产生bug
    return bestindex,bestvalue
def createtree(datamat,leaftype = regleaf,errtype = regerror,ops = (1,4)):
    feat,value = choosebestsplit(datamat,leaftype,errtype,ops)
    if feat == None:   #没有属性可以分割，直接返回回归值
        return value
    tree = {}    #依旧用字典来表示一个树
    tree['index'] = feat
    tree['value'] = value
    lefttree,righttree = splitdataset(datamat,feat,value)
    tree['left'] = createtree(lefttree,leaftype,errtype,ops)
    tree['right'] = createtree(righttree,leaftype,errtype,ops)
    return tree
#————————————————————————————————后剪枝———————————————————————————————#
#ops的设定限制了树的高度(复杂度)，相当于一个预剪枝的过程，不过一般很难控制效果
def istree(obj):
    return (type(obj).__name__ == 'dict')
def getmean(tree):    #若某一个节点要减掉，该节点就要返回其对应叶子节点的均值，注意：该函数会破坏原来树的结构
    if istree(tree['right']):
        tree['right'] = getmean(tree['right'])
    if istree(tree['left']):
        tree['left'] = getmean(tree['left'])  
    return (tree['left'] + tree['right'])/2.0  #这样算是树的均值的原因是因为训练时ops设置为(0,1)，可以保证每一个叶子节点上只有一个样本了，就可以如此运算得到均值
def prune(tree,testdata):   #testdata也要以矩阵形式输入，矩阵可以减去int数据等于在每个元素上减
    if np.shape(testdata)[0] == 0: #首先检查测试数据是否为空，为空就直接全部减掉，我们假设是一定过拟合的
        return getmean(tree)
    if (istree(tree['left'])) or (istree(tree['right'])):  #若有一边是树，不是值，就先切分一下
        ldata,rdata =  splitdataset(testdata,tree['index'],tree['value'])
    if istree(tree['left']):  #左边是树，左边递归调用剪枝函数
        tree['left'] = prune(tree['left'],ldata)
    if istree(tree['right']):  #右边是树，右边递归调用剪枝函数
        tree['right'] = prune(tree['right'],rdata)
    if (not istree(tree['left'])) and (not istree(tree['right'])):  #两边都是值，也要切分测试数据
        ldata,rdata =  splitdataset(testdata,tree['index'],tree['value'])
        errornomerge = sum(np.power(ldata[:,-1] - tree['left'],2)) + sum(np.power(rdata[:,-1] - tree['right'],2))
        mergemean = (tree['left'] + tree['right'])/2.0
        errormerge = sum(np.power(testdata[:,-1] - mergemean,2))
        if errormerge<errornomerge:
            print('merge')
            return mergemean
        else:
            return tree
    else:    #注意虽然上面对当前树的左右子树进行了递归运算，但是当树两边不都是数值时，这颗树还是要返回的，毕竟这个树才是函数返回值，否则相当于就没有返回值了(在左右子树不为叶子结点时)
        return tree  #注意递归使用顺序，返回上去的时候要这个return tree
#temptree = createtree(datamat,ops = (0,1))   #测试样例
#finaltree = prune(temp,datatest)                   #测试样例
#————————————————————————————————后剪枝———————————————————————————————#
#——————————————————————————————构建数模型———————————————————————————————#
def linearsolve(datamat):  #定义线性回归模型
    m,n = np.shape(datamat)
    X = np.mat(np.ones((m,n)))  #构造出线性回归矩阵形式，第一列为常数列项(截距)，Y=Xbeta + 误差
    Y = np.mat(np.ones((m,1)))
    X[:,1:n] = datamat[:,0:n-1]
    Y = datamat[:,-1]
    d = X.T*X
    if np.linalg.det(d) == 0.0:
        raise NameError('The matrix can not do inverse')
    coe  = d.I*(X.T*Y)
    return coe,X,Y
def modelleaf(datamat):
    coe,X,Y = linearsolve(datamat)
    return coe
def modelerror(datamat):  #还是以回归的值与实际值差的平方和作为误差
    coe,X,Y = linearsolve(datamat)
    Yp = X*coe
    return sum(np.power(Y-Yp,2))
#modeltree = createtree(datamat2,modelleaf,modelerror,ops = (1,10))
#——————————————————————————————构建数模型———————————————————————————————#
#——————————————————————————————回归树预测———————————————————————————————#
def predictregtree(model,indata):  #当树没有分支时，只有一个值，那测试数据预测值很显然就是这个值，这是回归树的预测函数，只支持一个测试数据的输入
    return float(model)
def predictmodeltree(model,indata):   #这是模型树的预测函数,只支持一个测试数据的输入
    n = np.shape(indata)[1]
    X = np.mat(np.ones((1,n+1)))
    X[:,1:n+1] = indata
    return float(X*model)
def treeforecast(tree,indata,struct = predictregtree):  #这里默认这个数的类型是回归树
    if not istree(tree):  #如果这个树只是一个值了，直接调用预测函数就ok
        return struct(tree,indata)
    if indata[tree['index']]>tree['value']:   #如果大于节点值，则走向左子树
        if not istree(tree['left']):
            return struct(tree['left'],indata)
        else:
            return treeforecast(tree['left'],indata,struct)
    else:
        if not istree(tree['right']):
            return struct(tree['right'],indata)
        else:
            return treeforecast(tree['right'],indata,struct)
def createforecast(tree,testdata,struct = predictregtree):   #这里可以支持输入的测试数据为多个，是一个数据集
    m = np.shape(testdata)[0]
    yp = np.mat(np.zeros((m,1)))
    for i in range(m):
        yp[i,0] = treeforecast(tree,testdata[i,:],struct)
    return yp
#测试样例
filenamebiketrain = 'F:/机器学习实战/machinelearninginaction/Ch09/bikeSpeedVsIq_train.txt'
filenamebiketest = 'F:/机器学习实战/machinelearninginaction/Ch09/bikeSpeedVsIq_test.txt'
databiketrain = loaddata(filenamebiketrain)
databiketest = loaddata(filenamebiketest)
biketree = createtree(databiketrain,ops = (1,20))
bikepredict = createforecast(biketree,databiketest[:,0])
Rreg = np.corrcoef(bikepredict.T.tolist()[0],databiketest[:,-1].T.tolist()[0])[0,1]  #计算真实值与估计之间相关系数
biketree2 = createtree(databiketrain,modelleaf,modelerror,ops = (1,20))
bikepredict2 = createforecast(biketree2,databiketest[:,0],predictmodeltree)
Rmodel = np.corrcoef(bikepredict2.T.tolist()[0],databiketest[:,-1].T.tolist()[0])[0,1]
coe,X,Y = linearsolve(databiketrain)   #如果只对数据进行线性回归，比较效果如何
linearpredict = []
for i in range(np.shape(databiketest)[0]):
    linearpredict.append(databiketest[i,0]*coe[1,0]+coe[0,0])
Rlinear = np.corrcoef(linearpredict,databiketest[:,-1].T.tolist()[0])[0,1]
#——————————————————————————————回归树预测———————————————————————————————#


        
    

    
        
            
            
            
    

    
