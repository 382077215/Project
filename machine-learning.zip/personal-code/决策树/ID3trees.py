from math import log
import matplotlib.pyplot as plt
import numpy as np
#dataset用list嵌套的方式输入
#属性标签要和数据集的每一个数据始终一一对应
def classent(dataset):   #定义一个求信息熵的函数
    ent = 0.0
    samplenum = len(dataset)
    label = {}
    for i in dataset:
        temp = i[-1]
        if temp not in label.keys():
            label[temp] = 0
        label[temp] += 1
    for key in label:
        prob = float(label[key])/samplenum
        ent += -prob*log(prob,2)
    return ent
def splitdataset(dataset,axis,value):  #对于给定情况下数据集分割
    data = []    #给定某一个属性特征，对于一个属性值上进行划分(yes与no划分，划分后不再包含该属性值)
    for i in dataset:
        if i[axis] == value:
            datatemp = i[:axis]+i[axis+1:]
            data.append(datatemp)
    return data
def choose(dataset):  #根据信息增益选择特征
    numfeatures = len(dataset[0])-1
    baseent = classent(dataset)
    bestgain = 0.0
    bestfeature = -1
    for i in range(numfeatures):
        feature = [example[i] for example in dataset]
        uniquefeature = set(feature)
        newent = 0.0
        for value in uniquefeature:
            subdataset = splitdataset(dataset,i,value)
            prob = len(subdataset)/float(len(dataset))
            newent += prob*classent(subdataset)
        tempgain = baseent-newent
        if (tempgain>bestgain):
            bestgain = tempgain
            bestfeature = i
    return bestfeature
def majorclass(classlist):#一个分支有多个类，投票来分类
    classcount = {}
    for vote in classlist:  #classlist为只一个分支上所有样本的所属类别
        if vote not in classcount.keys():
            classcount[vote] = 0
            classcount[vote] += 1
    sortclass = sorted(classcount.items(),key = lambda x:x[1],reverse = True)
    return sortclass[0][0]
#利用递归的方式来构造决策树
#不考虑剪枝情况下只有当某个分支只有一种类别或者遍历完所有属性才会递归结束
def createtree(dataset,labels,temp,tempmax = 0):
    classlist = [example[-1] for example in dataset]
    if dataset == []:
        return tempmax
    if classlist.count(classlist[0]) == len(classlist):  #全部属于一类
        return classlist[0]
    if len(dataset[0]) == 1:   #遍历完了所有特征
        return majorclass(classlist)
    bestfeature = choose(dataset)
    bestfeaturelabel = labels[bestfeature]
    tree = {bestfeaturelabel:{}}
    del(labels[bestfeature])  #选择过一次的特征后代就不会再用了，在标签中也需要删除
    featurevalues = set(temp[:,bestfeature].T.tolist()[0])
    temp=np.delete(temp,bestfeature,axis=1)
    for value in featurevalues:
        sublabels = labels[:] #只将值复制过来，而不是共享一个存储地址
        tree[bestfeaturelabel][value] = createtree(splitdataset(dataset,bestfeature,value),sublabels,temp,majorclass(classlist))
    return tree
def getnumleaf(tree): #计算叶子个数
    numleaf = 0
    firststr = list(tree.keys())[0]
    secondict = tree[firststr]
    for key in secondict.keys():
        if type(secondict[key]).__name__ == 'dict':
            numleaf += getnumleaf(secondict[key])
        else:
            numleaf += 1
    return numleaf
def getdepth(tree): #计算树高
    maxdepth = 0
    firststr = list(tree.keys())[0]
    secondict = tree[firststr]
    for key in secondict.keys():
        if type(secondict[key]).__name__ == 'dict':
            tempdepth = 1 + getdepth(secondict[key])
        else:
            tempdepth = 1
        if tempdepth>maxdepth:
            maxdepth = tempdepth
    return maxdepth
#定义分类函数
def classify(tree,labels,test):
    firststr = list(tree.keys())[0]
    secondist = tree[firststr]
    featureindex = labels.index(firststr)
    for key in secondist.keys():
        if test[featureindex] == key:
            if type(secondist[key]).__name__ == 'dict':
                classlabel = classify(secondist[key],labels,test)
            else:
                classlabel = secondist[key]
    return classlabel
def storetree(tree,filename):
    import pickle  #使用该模块序列化对象
    fw = open(filename,'wb')  #pickle默认存储方式为二进制模式，故使用wb+
    pickle.dump(tree,fw)   #将tree序列化写入到路径中
    fw.close()
def gettree(filename):
    import pickle
    fr = open(filename,'rb') #同样地，由于二进制模式，使用rb
    tree = pickle.load(fr)  #反序列化，将其解析为一个python对象
    fr.close()
    return tree
#--------------------------测试样例-------------------------------------
fr = open('F:/机器学习实战/machinelearninginaction/Ch03/lenses.txt','r')
dataset = [x.strip().split('\t') for x in fr.readlines()] #逐行读取数据并且去除收尾空格，按照\t分隔开变为list
traindataset = dataset[0:6]+dataset[8:14]+dataset[16:22]
globaldata = np.mat(traindataset)
testdataset = dataset[6:8]+dataset[14:16]+dataset[22:24]
featurelabels = ['age','symptom','astigmatic','tear']
finaltree = createtree(traindataset,featurelabels,globaldata)  #构造决策树
featurelabels = ['age','symptom','astigmatic','tear']
storetree(finaltree,'F:/毕业设计/code/ID3tree.txt') #存储树，因为训练时间太久了
predict = []
initial = [i[-1] for i in testdataset]
for i in testdataset:
    predict.append(classify(finaltree,featurelabels,i))
pcorrect = sum([1 if predict[i]==initial[i] else 0 for i in range(len(predict))])/len(predict)
#--------------------------测试样例-------------------------------------

#--------------------------交叉验证--------------------------------------
crossans = []
for j in range(24):
    if (j+18)<24:
        crosstraindata = dataset[j:j+18]
        crosstestdata = dataset[j+18:24]+dataset[0:j]
    else:
        crosstraindata = dataset[j:24]+dataset[0:j-6]
        crosstestdata = dataset[j-6:j]
    globaldata = np.mat(crosstraindata)
    crossfeaturelabels = ['age','symptom','astigmatic','tear']
    crossfinaltree = createtree(crosstraindata,crossfeaturelabels,globaldata)  #构造决策树
    crossfeaturelabels = ['age','symptom','astigmatic','tear']
    crosspredict = []
    crossinitial = [i[-1] for i in crosstestdata]
    for i in crosstestdata:
        crosspredict.append(classify(crossfinaltree,crossfeaturelabels,i))
    crosspcorrect = sum([1 if crosspredict[i]==crossinitial[i] else 0 for i in range(len(crosspredict))])/len(crosspredict)
    crossans.append(crosspcorrect)
print(sum(crossans)/len(crossans))
        
    
    
    
            


    
    


        
        
