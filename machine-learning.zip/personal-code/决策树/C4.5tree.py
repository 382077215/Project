from math import log
import numpy as np
def splitdataset(dataset,axis,value):  #对于给定情况下数据集分割
    data = []    #给定某一个属性特征，对于一个属性值上进行划分(yes与no划分，划分后不再包含该属性值)
    for i in dataset:
        if i[axis] == value:
            datatemp = i[:axis]+i[axis+1:]
            data.append(datatemp)
    return data
def classent(dataset):   #定义一个求信息熵的函数
    ent = 0.0
    samplenum = len(dataset)
    label = {}
    for i in dataset:
        temp = i[-1]
        if temp not in label.keys():
            label[temp] = 0
        label[temp] += 1
    for key in label:
        prob = float(label[key])/samplenum
        ent += -prob*log(prob,2)
    return ent
def choose(dataset):  #根据信息增益率选择特征
    numfeatures = len(dataset[0])-1
    baseent = classent(dataset)
    bestgainpercent = 0.0
    bestfeature = -1
    for i in range(numfeatures):
        feature = [example[i] for example in dataset]
        uniquefeature = set(feature)
        newent = 0.0
        newentfeature = 0.0
        for value in uniquefeature:
            subdataset = splitdataset(dataset,i,value)
            prob = len(subdataset)/float(len(dataset))
            newent += prob*classent(subdataset)
            newentfeature += -prob*log(prob,2)
        tempgainpercent = (baseent-newent)/newentfeature
        if (tempgainpercent>bestgainpercent):
            bestgainpercent = tempgainpercent
            bestfeature = i
    return bestfeature
def majorclass(classlist):#一个分支有多个类，投票来分类
    classcount = {}
    for vote in classlist:  #classlist为只一个分支上所有样本的所属类别
        if vote not in classcount.keys():
            classcount[vote] = 0
            classcount[vote] += 1
    sortclass = sorted(classcount.items(),key = lambda x:x[1],reverse = True)
    return sortclass[0][0]
def createtree(dataset,labels,temp,tempmax = 0):
    classlist = [example[-1] for example in dataset]
    if dataset == []:
        return tempmax
    if classlist.count(classlist[0]) == len(classlist):  #全部属于一类
        return classlist[0]
    if len(dataset[0]) == 1:   #遍历完了所有特征
        return majorclass(classlist)
    bestfeature = choose(dataset)
    bestfeaturelabel = labels[bestfeature]
    tree = {bestfeaturelabel:{}}
    del(labels[bestfeature])  #选择过一次的特征后代就不会再用了，在标签中也需要删除
    featurevalues = set(temp[:,bestfeature].T.tolist()[0])
    temp=np.delete(temp,bestfeature,axis=1)
    for value in featurevalues:
        sublabels = labels[:] #只将值复制过来，而不是共享一个存储地址
        tree[bestfeaturelabel][value] = createtree(splitdataset(dataset,bestfeature,value),sublabels,temp,majorclass(classlist))
    return tree
def classify(tree,labels,test):
    firststr = list(tree.keys())[0]
    secondist = tree[firststr]
    featureindex = labels.index(firststr)
    for key in secondist.keys():
        if test[featureindex] == key:
            if type(secondist[key]).__name__ == 'dict':
                classlabel = classify(secondist[key],labels,test)
            else:
                classlabel = secondist[key]
    return classlabel
fr = open('F:/机器学习实战/machinelearninginaction/Ch03/lenses.txt','r')
dataset = [x.strip().split('\t') for x in fr.readlines()]
traindataset = dataset[0:6]+dataset[8:14]+dataset[16:22]
globaldata = np.mat(traindataset)
testdataset = dataset[6:8]+dataset[14:16]+dataset[22:24]
featurelabels = ['age','symptom','astigmatic','tear']
finaltree = createtree(traindataset,featurelabels,globaldata)
featurelabels = ['age','symptom','astigmatic','tear']
predict = []
initial = [i[-1] for i in testdataset]
for i in testdataset:
    predict.append(classify(finaltree,featurelabels,i))
pcorrect = sum([1 if predict[i]==initial[i] else 0 for i in range(len(predict))])/len(predict)
#--------------------------交叉验证--------------------------------------
crossans = []
for j in range(24):
    if (j+18)<24:
        crosstraindata = dataset[j:j+18]
        crosstestdata = dataset[j+18:24]+dataset[0:j]
    else:
        crosstraindata = dataset[j:24]+dataset[0:j-6]
        crosstestdata = dataset[j-6:j]
    globaldata = np.mat(crosstraindata)
    crossfeaturelabels = ['age','symptom','astigmatic','tear']
    crossfinaltree = createtree(crosstraindata,crossfeaturelabels,globaldata)  #构造决策树
    crossfeaturelabels = ['age','symptom','astigmatic','tear']
    crosspredict = []
    crossinitial = [i[-1] for i in crosstestdata]
    for i in crosstestdata:
        crosspredict.append(classify(crossfinaltree,crossfeaturelabels,i))
    crosspcorrect = sum([1 if crosspredict[i]==crossinitial[i] else 0 for i in range(len(crosspredict))])/len(crosspredict)
    crossans.append(crosspcorrect)
print(sum(crossans)/len(crossans))

