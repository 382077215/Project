import re
import numpy as np
from bayes import *
def wordbag(vocablist,data):  #vocablist为词汇表，data为一个句子，list格式
    returnvec = [0]*len(vocablist)
    for word in data:
        if word in vocablist:
            returnvec[vocablist.index(word)] += 1
    return returnvec
def text(string):
    stringlist = re.split(r'\W+',string)  #利用正则表达式来分割，\W表示非字母汉字下划线的字符，*表示出现一次或多次
    return [i.lower() for i in stringlist if len(i)>2]  #先筛选再转化为小写
def spam():
    doclist = []
    classlist = []
    fulltext = []
    for i in range(1,26):  #spam表示垃圾邮件，ham表示正常邮件，1表示垃圾邮件，0表示正常邮件
        wordlist = text(open('F:/机器学习实战/machinelearninginaction/Ch04/email/spam/'+str(i)+'.txt','r').read())
        doclist.append(wordlist)  #一个list中包含多个list
        fulltext.extend(wordlist)   #只有一个list包含所有单词
        classlist.append(1)
        wordlist = text(open('F:/机器学习实战/machinelearninginaction/Ch04/email/ham/'+str(i)+'.txt','r').read())#有时候编码错误无法读入可能包含非法字符，需要检查一下文本
        doclist.append(wordlist)  
        fulltext.extend(wordlist)   
        classlist.append(0)
    vocablist = createvoclist(doclist)
    training = [i for i in range(50)]
    testing = []
    for i in range(10):   #随机选取测试数据与训练数据，这里的选取方式是不重复的，
        randindex = int(np.random.uniform(0,len(training)))
        testing.append(training[randindex])
        del(training[randindex])
    traindata = []
    trainclass = []
    for index in training:
        traindata.append(wordbag(vocablist,doclist[index]))
        trainclass.append(classlist[index])
    p0,p1,pclass = trainnb(traindata,trainclass)
    errorcount = 0
    for index in testing:
        temp = wordbag(vocablist,doclist[index])
        if classifynb(np.array(temp),p0,p1,pclass) != classlist[index]:
            errorcount += 1
    print('error rate: %f'%(errorcount/10.0))
for i in range(10):
    spam()
    
        
