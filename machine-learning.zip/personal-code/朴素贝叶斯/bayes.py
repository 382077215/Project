import numpy as np
#这里假设是二分类问题
def loaddata():   #测试数据(也看作是训练数据)
    doc = [['my', 'dog', 'has', 'flea', 'problems', 'help', 'please'],
                 ['maybe', 'not', 'take', 'him', 'to', 'dog', 'park', 'stupid'],
                 ['my', 'dalmation', 'is', 'so', 'cute', 'I', 'love', 'him'],
                 ['stop', 'posting', 'stupid', 'worthless', 'garbage'],
                 ['mr', 'licks', 'ate', 'my', 'steak', 'how', 'to', 'stop', 'him'],
                 ['quit', 'buying', 'worthless', 'dog', 'food', 'stupid']]
    classvec = [0,1,0,1,0,1]    #1 表示侮辱性语言， 0 表示正常言论
    return doc,classvec
def createvoclist(data):  #创建包含在文档(所有语句)中所有出现词语的列表，但不重复，文档格式如loaddata数据中所示，即构建一个词汇表
    vocab = set([])
    for document in data:
        vocab = vocab|set(document)  #集合的并集
    return list(vocab)
def wordvector(vocablist,data):   #第一个参数为词汇表，第二个参数为输入一条语句(向量格式)
    returnvec = [0]*len(vocablist)
    for word in data:
        if word in vocablist:
            returnvec[vocablist.index(word)] += 1
        else:
            print('%s is not in vocabualry'%word)
    return returnvec
def trainnb(doc,classvec):   #这里doc中每一个样本都是对应词汇表中每一个单词出现的频数，均是list格式
    numdoc = len(doc)  #句子个数，样本个数
    numword = len(doc[0])  #单词个数
    pclass = sum(classvec)/float(numdoc)  #计算类别概率，这里计算属于侮辱性类别的概率
    p0num = np.ones(numword)  #初始化不同类别对所有特征的条件概率
    p1num = np.ones(numword)  #这样以1为分子初始化，2为分母初始化为了防止一次不出现导致的概率为0，这是不合理的。
    p0union = 2.0
    p1union = 2.0
    for i in range(numdoc):
        if classvec[i] == 1:
            p1num += doc[i]  #计算在类别1中词汇表中每个词语各出现了几次
            p1union += sum(doc[i])  #计算在类别1中词汇表中的词总共出现了几次
        else:
            p0num += doc[i]
            p0union += sum(doc[i])
    p1vect = np.log(p1num/p1union)  #这样做避免最后概率连乘时概率太小而变为0，去log之后概率连乘变为连加即ln(ab) = ln(a)+ln(b)
    p0vect = np.log(p0num/p0union)  #这种做法虽然导致最后概率结果与原来不同，但是f(x)与ln(f(x))在相同区域内单调性极值点一样，因此最后根据概率大小判断属于哪一类，取ln是不影响的
    return p0vect,p1vect,pclass
def classifynb(vec,p0vec,p1vec,pclass):  #vec需要array类型，vec表示测试数据各个单词(词汇表中的，一一对应)的出现次数，出现多次相当于概率平方
    p0 = sum(vec*p0vec)+np.log(1-pclass)
    p1 = sum(vec*p1vec)+np.log(pclass)  #分类公式类似于\prod_{i=1}^{d}p_{i}^{n_{i}}，可以看到如果出现0次，连乘时这个词的对应概率为p^{0}=1
    if p0>p1:
        return 0
    else:
        return 1
def testnb():    #分类测试
    doc,classvec = loaddata()
    myvocablist = createvoclist(doc)
    traindoc = []
    for i in doc:
        traindoc.append(wordvector(myvocablist,i))
    p0vect,p1vect,pclass = trainnb(traindoc,classvec)
    test = ['love','my','dalmation']
    testvec = np.array(wordvector(myvocablist,test))
    print(test,end = ' ')
    print('It is classified as %d'%classifynb(testvec,p0vect,p1vect,pclass))
    test = ['stupid','garbage']
    testvec = np.array(wordvector(myvocablist,test))
    print(test,end = ' ')
    print('It is classified as %d'%classifynb(testvec,p0vect,p1vect,pclass))
    test = ['dog','dog']
    testvec = np.array(wordvector(myvocablist,test))
    print(test,end = ' ')
    print('It is classified as %d'%classifynb(testvec,p0vect,p1vect,pclass))
#testnb()

    
    
        

