import numpy as np
def loaddata(filename): #矩阵格式数据
    data = []
    f = open(filename,'r')
    for line in f.readlines():
        curline = line.strip().split('\t')
        finline = list(map(float,curline))
        data.append(finline)
    return np.mat(data)
def dise(veca,vecb):  #计算样之间的欧式距离
    d = np.sqrt(np.sum(np.power(veca-vecb,2)))
    return d
def randomcenter(data,k):  #初始时随机生成类别中心
    n = np.shape(data)[1]
    cen = np.mat(np.zeros((k,n)))
    for j in range(n):
        minj = min(data[:,j])   #计算变量的取值范围
        rangej = float(max(data[:,j])-minj)
        cen[:,j] = minj+rangej*np.random.rand(k,1)
    return cen
def kmeans(data,k,distance = dise,createcenter = randomcenter):   #k均值聚类
    m = np.shape(data)[0]
    clusterdata = np.mat(np.zeros((m,2)))  #记录数据样本所属于中心点的情况,第一列是所属中心点位置索引，第二个位置记录离中心点的距离
    cent = createcenter(data,k)   #初始化聚类中心
    clusterchange = True  #用于记录聚类情况是否改变
    while clusterchange: #停机条件为每个样本点的所属类别都不再改变
        clusterchange = False
        for i in range(m):
            mindist = np.inf
            minindex = -1
            for j in range(k):
                tempdist = distance(data[i,:],cent[j,:])
                if tempdist<mindist:
                    mindist = tempdist
                    minindex = j
            if clusterdata[i,0] != minindex:   #如果发现样本的所属类别改变了，则下一次还需要再运行算法
                clusterchange = True
            clusterdata[i,:] = minindex,mindist**2  #更新记录
        for j in range(k):  #更新聚类中心
            temp = data[np.nonzero(clusterdata[:,0]==j)[0],:]  #选出属于这一类的样本
            cent[j,:] = np.mean(temp,axis = 0)
    return cent,clusterdata
#——————————————————————————————————————测试样例————————————————————————————————————————————
filename1 = 'F:/机器学习实战/machinelearninginaction/Ch10/testSet.txt'
datamat1 = loaddata(filename1)
cent1,clusterdata1= kmeans(datamat1,4)
#——————————————————————————————————————测试样例————————————————————————————————————————————
#———————————————————————————————————利用二分Kmeans获得更好结果——————————————————————————————————————
#衡量聚类好坏一种方式是看每一个样本离中心点的距离，距离之和(误差)越小则认为效果要好
'''流程为将所有点看作一个类，当类数小于k时，对于每一个类，计算2均值聚类之后所有类的总误差，使误差最小的那一类进行划分，直至到达k类'''
def seckmeans(data,k,distance = dise):
    m = np.shape(data)[0]
    clusterdata = np.mat(np.zeros((m,2)))  #记录数据样本所属于中心点的情况,第一列是所属中心点位置索引，第二个位置记录离中心点的距离,初始都属于第0类(index=0)
    cent0 = np.mean(datamat1,axis = 0).tolist()[0]  #初始时假设所有样本都是一个类，计算类的中心点
    centlist = [cent0]
    for j in range(m):
        cluster[j,1] = distance(np.mat(cent0),data[j,:])**2
    while len(centlist)<k:   #当不足k类时就继续
        minloss = np.inf
        for i in range(len(cenlist)):
            temp = data[np.nonzero(clusterdta[:,0]==i)[0],:]
            centmat,splitclust = kmeans(temp,2)   #对于每一个类的数据进行2均值聚类
            temploss = np.sum(splitclust[:,1])
            tempotherloss = np.sum(clusterdata[np.nonzero(clusterdata[:,0] != i)[0],1])
            if (temploss + tempotherloss)<minloss: #计算这样划分后结果的聚类误差之和
                bestsplit = i
                bestcents = centmat
                minloss = temploss+tempotherloss
                bestclusterdata = splitclust.copy()
        bestclusterdata[np.nonzero(bestclusterdata[:,0]==0)[0],0] = bestsplit  #更新新划分出的两个类的类别，一个为原来划分类的类索引
        bestclusterdata[np.nonzero(bestclusterdata[:,0]==1)[0],0] = len(cenlist)  #一个为原来类别数新增加出来的一个类索引
        cenlist[bestsplit] = bestcents[0,:]   #更新类别的中心点
        cenlist.append(bestcents[1,:])
        clusterdata[np.nonzero(clusterdata[:,0]==bestsplit)[0],:] = bestclusterdata
        return np.mat(centlist),clusterdata
#——————————————————————————————————————测试样例————————————————————————————————————————————
filename2 = 'F:/机器学习实战/machinelearninginaction/Ch10/testSet2.txt'
datamat2 = loaddata(filename2)
cent2,clusterdata2= kmeans(datamat2,3)
#——————————————————————————————————————测试样例————————————————————————————————————————————
        
                
            
            

    





