#构建FP树来发现频繁集
class treenode():
    def __init__(self,name,numoccur,parent):
        self.name = name
        self.count = numoccur
        self.nodelink = None  #用于连接相似的元素项
        self.parent = parent
        self.children = {}  #将子结点存入字典，键为结点名称，值为结点类型
    def inc(self,numoccur):  #对count变量增加给定值
        self.count += numoccur
    def disp(self,ind = 1):   #用作打印调试
        print('  '*ind,end = '')
        print(self.name,end = ' ')
        print(self.count)
        for child in self.children.values():
            child.disp(ind+1)
#构建FP树
#对每个事务进行计数，过滤去为满足最小支持度的数据再按出现频率对其进行排序
#依次将每一个事物加入到FP树种
def updateheader(nodetotest,targetnode):
    while nodetotest.nodelink != None:  #对相同元素进行连接
        nodetotest = nodetotest.nodelink
    nodetotest.nodelink = targetnode
def updatetree(items,intree,headertable,count):
    if items[0] in intree.children:  #查看每个事务第一个元素是否已经是根结点的孩子，如果是继续向下寻找，不是则创建新的路径
        intree.children[items[0]].inc(count)  #更新该结点的出现次数的计数
    else:
        intree.children[items[0]] = treenode(items[0],count,intree)  #否则就创建新路径，父节点是Intree，就是输入的根结点
        if headertable[items[0]][1] == None:
            headertable[items[0]][1] = intree.children[items[0]] #更新头指针表的对应元素指向
        else:
            updateheader(headertable[items[0]][1],intree.children[items[0]])
    if len(items)>1:
        updatetree(items[1::],intree.children[items[0]],headertable,count)  #挂完事务中一个元素之后递归操作
        #最后一次，两个元素，挂完一个，最后一个没挂，最后一次递归，只有一个元素输入，挂完后不再递归
def createtree(dataset,minsup = 1):  #dataset以字典集合格式输入，每个集合表示一个事务，一个事务中的元素是唯一的
    headertable = {}  #计数
    for tran in dataset:
        for item in tran:
            headertable[item] = headertable.get(item,0) + dataset[tran]
    delete = []
    for k in headertable.keys():  #去除不满足最小支持度的(单个集)
        if headertable[k]<minsup:
            delete.append(k)
    for i in delete:
        del headertable[i]
    freqitem = set(headertable.keys())
    if len(freqitem) == 0:  #没有元素就返回空
        return None,None
    for k in headertable:
        headertable[k] = [headertable[k],None]  #更改字典存储格式，创建头指针表
    retree = treenode('Null Set',1,None)
    for transet,count in dataset.items():
        locald = {}
        for item in transet:
            if item in freqitem:
                locald[item] = headertable[item][0]
        if len(locald)>0:
            orderitems = [v[0] for v in sorted(locald.items(),key = lambda x:x[1],reverse = True)] #对每个元素出现的绝对频率进行排序
            updatetree(orderitems,retree,headertable,count)   #更新树
    return retree,headertable
#————————————————————————————————测试————————————————————————————————————————————————

def loadSimpDat():
    simpDat = [['r', 'z', 'h', 'j', 'p'],
               ['z', 'y', 'x', 'w', 'v', 'u', 't', 's'],
               ['z'],
               ['r', 'x', 'n', 'o', 's'],
               ['y', 'r', 'x', 'z', 'q', 't', 'p'],
               ['y', 'z', 'x', 'e', 'q', 's', 't', 'm']]
    return simpDat
def createSet(dataSet):
    retDict = {}
    for trans in dataSet:
        retDict[frozenset(trans)] = 1
    return retDict
#————————————————————————————————测试————————————————————————————————————————————————
#从FP树种挖掘频繁集
def ascendtree(leafnode,path):  #往上搜索树
    if leafnode.parent != None:
        path.append(leafnode.name)
        ascendtree(leafnode.parent,path)
def findpath(base,treenode):  #输入元素符号，第一个该元素符号的结点
    condpats = {}
    while treenode != None:
        path = []
        ascendtree(treenode,path)
        if len(path)>1:
            condpats[frozenset(path[1:])] = treenode.count  #记录路径
        treenode = treenode.nodelink  #继续向下寻找满足条件的点
    return condpats
simpdata = loadSimpDat()
initset = createSet(simpdata)
tree,header = createtree(initset,3)
q = findpath('r',header['r'][1])
#创建条件FP树

def minetree(intree,headertable,minsup,path,freqlist): 
    initial = [v[0] for v in sorted(headertable.items(),key = lambda x:x[1][0])] #从小到大排序，但这里都是频繁项集
    for base in initial:  #构建以base为条件的FP树
        newpath = path.copy()
        newpath.add(base)
        freqlist.append(newpath)  #加入频繁项集
        cond = findpath(base,headertable[base][1])  #构建频繁路径
        mycondtree,myhead = createtree(cond,minsup)  #利用找出来的频繁路径构建FP树
        if myhead != None:
            print('conditional tree for:',end = ' ')
            print(newpath)
            mycondtree.disp(1)
            minetree(mycondtree,myhead,minsup,newpath,freqlist)  #如果这个频繁项集存在条件树，则继续向下递归，构建元素更多的条件树
freqlist = []  #记录FP树中的所有频繁项集合，不单是单个元素，也包括元素的组合！！！
#minetree(tree,header,3,set([]),freqlist)

finaldata = [line.split() for line in open('F:/机器学习实战/machinelearninginaction/Ch12/kosarak.dat').readlines()]
finalinitset = createSet(finaldata)
finaltree,finalheader = createtree(finalinitset,100000)
minetree(finaltree,finalheader,100000,set([]),freqlist)
        
        
