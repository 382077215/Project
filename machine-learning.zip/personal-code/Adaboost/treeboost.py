import numpy as np
#———————————————————————————————————————测试数据集——————————————————————————————————————
def loadsimpdata():
    datamat = np.mat([[1.0,2.1],[2.0,1.1],[1.3,1.0],[1.0,1.0],[2.0,1.0]])
    classlabel = [1.0,1.0,-1.0,-1.0,1.0]
    return datamat,classlabel
datamat,classlabel = loadsimpdata()
#———————————————————————————————————————测试数据集——————————————————————————————————————
#构造单层决策树
def classify(datamat,dimen,val,treeindex): #分别为数据集，变量下标，比较的值以及分支标签(用于预测样本属于哪一类)
    returnarray = np.mat(np.ones((np.shape(datamat)[0],1)))  #先假设全部是正类
    if treeindex == 'le':  #如果标签为小于
        returnarray[datamat[:,dimen]<=val] = -1.0  #将变量小于阈值的分到反类
    else:
        returnarray[datamat[:,dimen]>val] = -1.0  #将变量大于阈值的分到反类
    return returnarray
def buildtree(datamat,classlabel,D): #D为权重向量(Adaboost上的数据分布)
    labelmat = np.mat(classlabel).T
    m,n = np.shape(datamat)
    besttree = {}
    numstep = 10.0  #定义寻找变量(连续)切分点的个数，这里简化处理了，一般是考虑所有取值之间中位数变量
    bestest = np.mat(np.zeros((m,1)))  #记录最佳预测值
    minerror = np.inf
    for i in range(n): #第一次循环变量所有可能特征
        rangemin = datamat[:,i].min()   #默认变量为连续变量，计算该变量的最大最小值
        rangemax = datamat[:,i].max()
        stepsize = (rangemax-rangemin)/numstep
        for j in range(-1,int(numstep)+1):  #遍历所有切分点(设置阈值)，也可以考虑将阈值设置到取值范围之外(j取两段时决策树都会有一侧没有训练样本，即将样本都预测为一类)
            for index in ['le','gt']:  #le表示小于或等于，gt表示大于  (这是两种情况，因为单层二叉树，左子树要么正要么反，这层循环就将这两种情况遍历一些)
                val = rangemin+float(j)*stepsize
                predictvalue = classify(datamat,i,val,index)
                errormat= np.mat(np.ones((m,1)))  
                errormat[predictvalue==labelmat] = 0
                weighterror = D.T*errormat
                if weighterror<minerror:
                    minerror = weighterror
                    bestest = predictvalue.copy()
                    besttree['dim'] = i
                    besttree['val'] = val
                    besttree['index'] = index  #默认全为正类，index为le，小于等于阈值全为反类，index为gt，大于阈值全为反类
    return besttree,minerror,bestest
D = np.mat(np.ones((5,1))/5)  #定义权重，这边假设权重一样大
#—————————————————————————————————单层树的测试样例————————————————————————————————————————————
simpletree,simpleerror,simpleclass = buildtree(datamat,classlabel,D)
#—————————————————————————————————单层树的测试样例————————————————————————————————————————————
def adaboost(datamat,classlabel,numiter = 40):
    weakclass = []  #用于存储训练得到的各个基分类器
    m = np.shape(datamat)[0]
    D = np.mat(np.ones((m,1))/m) #计算初始权值(样本的初始分布)
    finalclassest = np.mat(np.zeros((m,1)))  #记录最终的集成分类器
    for i in range(numiter):  #训练基分类器个数最多为40个(默认)
        tree,error,classest = buildtree(datamat,classlabel,D)  #根据已知数据分布先进行一次基分类器训练
        #这里还需要保证error<0.5，但由于模型简单，基本是满足的，故省去
        alpha = float(0.5*np.log((1-error)/max(error,1e-16)))  #防止分子过小溢出
        tree['alpha'] = alpha
        weakclass.append(tree)
        temp = np.multiply(-alpha*np.mat(classlabel).T,classest)
        D = np.multiply(D,np.exp(temp))
        D = D/D.sum()  #正则化
        finalclassest += alpha*classest
        finalerror = np.multiply(np.sign(finalclassest) != np.mat(classlabel).T,np.mat(np.ones((m,1))))
        errorrate = finalerror.sum()/m
        if errorrate == 0.0:  #已经无训练误差，则不用再继续训练基分类器
            break
    return weakclass,finalclassest
#—————————————————————————————————Adaboost测试样例————————————————————————————————————————————
adaclass,tempans = adaboost(datamat,classlabel,9)
#—————————————————————————————————Adaboost测试样例————————————————————————————————————————————
def adaclassify(data,adatree): #定义Adaboost的分类
    datamat = np.mat(data)
    m = np.shape(datamat)[0]
    finalclass = np.mat(np.zeros((m,1)))
    for i in range(len(adatree)):
        classest = classify(datamat,adatree[i]['dim'],adatree[i]['val'],adatree[i]['index'])
        finalclass += classest*adatree[i]['alpha']
    return np.sign(finalclass)
ans = adaclassify([[0,0],[5,5]],adaclass)
#———————————————————————————————————Adaboost的应用————————————————————————————————————————————
def loadtestdata(filename):
    numfeature = len(open(filename,'r').readline().split('\t'))
    data = []
    label = []
    f = open(filename,'r')
    for line in f.readlines():
        linedata = []
        currline = line.split('\t')
        for i in range(numfeature-1):
            linedata.append(float(currline[i]))
        data.append(linedata)
        label.append(float(currline[-1]))
    return data,label
traindata,trainlabel = loadtestdata('F:/机器学习实战/machinelearninginaction/Ch07/horseColicTraining2.txt')
testdata,testlabel = loadtestdata('F:/机器学习实战/machinelearninginaction/Ch07/horseColicTest2.txt')
def testadaboost(iternum):  #根据不同基分类器个数测试adaboost的性能
    adatree,finalans = adaboost(np.mat(traindata),trainlabel,iternum)
    pre = adaclassify(testdata,adatree)
    percenterror = np.mat(np.ones((np.shape(pre)[0],1)))[pre != np.mat(testlabel).T].sum()/np.shape(pre)[0]
    return percenterror
#Adaboost的错误率最终会趋于稳定，而不是随基分类器增加而减小(有可能反而会增加)

#ROC曲线 y轴为真阳率(TP/(TP+FN)) x轴为假阳率(FP/FP+TN)
def plotroc(classscore,label):
    import matplotlib.pyplot as plt
    current = [1.0,1.0]  #用于记录当前绘图光标停止的位置,初始位置为(1,1),即全部预测为正类
    ysum = 0  #计算ROC曲线下的面积
    numpos = sum(np.array(label)==1.0)  #计算训练样本中正类个数
    ystep = 1/float(numpos)  #计算y的步长,相当于1/TP+FN
    xstep = 1/float(len(label)-numpos)  #计算x的步长,相当于1/FP+TN
    sortindex = classscore.T.argsort() #将该矩阵(m*1)从小到到大排序，返回索引
    fig = plt.figure()
    ax = fig.add_subplot(1,1,1)
    for index in sortindex.tolist()[0]:  #将所有样本从得分最小的开始依次预测为反类
        if label[index] == 1.0:
            delx = 0
            dely = -ystep
        else:
            delx = -xstep
            dely = 0
            ysum += current[1] #面积计算时，只有x轴发生偏移，才需要加一下此时y轴高度
            #由于面积可以看作是多个长方形之和，长方形宽一样，只要计算长(y)的和即可
        ax.plot([current[0],current[0]+delx],[current[1],current[1]+dely],c = 'b')
        current = [current[0]+delx,current[1]+dely]
    ax.plot([0,1],[0,1],'b--')#蓝色虚线
    ax.axis([0,1,0,1])
    plt.show()
    return ysum*xstep
adatree,finalans = adaboost(np.mat(traindata),trainlabel)
auc = plotroc(finalans,trainlabel)

                
