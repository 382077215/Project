#logistics回归，梯度上升的方式估计参数
#w = w+lambda*grad  grad为梯度方向，lambda为步长
import numpy as np
def loaddata():
    datamat = []
    labelmat = []
    f = open('F:/机器学习实战/machinelearninginaction/Ch05/testSet.txt','r')
    for line in f.readlines():
        temp = line.strip().split()
        datamat.append([1.0,float(temp[0]),float(temp[1])])  #多了一个常数项
        labelmat.append(int(temp[2]))
    return datamat,labelmat
def sigmod(z):
    return 1.0/(1+np.exp(-z))
def gradascent(data,label):  #梯度上升函数，计算整个数据集的梯度
    datamat = np.mat(data)
    labelmat = np.mat(label).T
    m,n = np.shape(datamat)
    lam = 0.001
    maxiter = 500  #优化算法的迭代次数
    weights = np.mat(np.ones((n,1)))  #初始化误差
    for k in range(maxiter):
        sig = sigmod(datamat*weights)
        error = labelmat - sig
        weights = weights + lam*datamat.T*error   #由推导，权重更新的梯度方向就是言则误差的方向
    return weights
def randgrad(data,label,numiter = 150):  #随机梯度上升方法，计算每一个样本梯度
    data = np.mat(data)
    m,n = np.shape(data)
    weights = np.mat(np.ones((n,1)))
    for j in range(numiter):
        dataindex = list(range(m))
        for i in range(m):
            lam = 0.01+4/(1.0+i+j)   #步长每一次迭代都会减少，如果j<<max(i)，lam也不是严格下降的
            index = int(np.random.uniform(0,len(dataindex)))  #每一次选一个随机样本计算梯度
            h = sigmod(data[index,:]*weights)
            error = label[index] - h
            weights = weights+(lam*error*data[index,:]).T
            del dataindex[index]  #使用过的样本点删去，下一次外循环就不再使用了
    return weights
def classify(test,weight):
    prob = sigmod(test*weight)
    if prob>0.5:
        return 1.0
    else:
        return 0.0
def test():
    ftrain = open('F:/机器学习实战/machinelearninginaction/Ch05/horseColicTraining.txt','r')
    ftest = open('F:/机器学习实战/machinelearninginaction/Ch05/horseColicTest.txt','r')
    traindata = []
    trainlabel = []   #21个特征
    for line in ftrain.readlines():
        temp = line.strip().split('\t')
        linearr = []
        for i in range(21):
            linearr.append(float(temp[i]))
        traindata.append(linearr)
        trainlabel.append(float(temp[21]))
    trainweights = randgrad(traindata,trainlabel,500)
    errorcount = 0.0
    numtest = 0.0
    for line in ftest.readlines():
        numtest +=  1
        currline = line.strip().split('\t')
        linearr = []
        for i in range(21):
            linearr.append(float(temp[i]))
        if int(classify(np.mat(linearr),trainweights)) != int(currline[21]):
            errorcount += 1
    errorrate = float(errorcount)/numtest
    print(errorrate)
    print(trainweights)
    return errorrate
def multitest():
    n = 10
    errorsum = 0.0
    for k in range(n):
        errorsum += test()
    print(errorsum/n)
multitest()
