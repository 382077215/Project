#APRIORI：一个集合是频繁集合，那么其所有子集也是频繁的
#一个集合非频繁，那么其超集也是非频繁的
def loaddata():
    return [[1,3,4],[2,3,5],[1,2,3,5],[2,5]]
def createc1(dataset):  #选出所有单个集合
    c1 = []
    for tran in dataset:
        for item in tran:
            if not [item] in c1:
                c1.append([item])
    return list(map(frozenset,c1))
def scand(d,ck,minsupport): #数据集，候选集列表以及感兴趣集的最小支持度(用于过滤集合)
    sscnt = {}
    for tid in d:
        for can in ck:   
            if can.issubset(tid):   #如果can是数据集的一个子集(一定是要是一个子集才会列入频繁集字典中计算得分)
                if can not in sscnt.keys():  #计算候选列表集中每个元素作为数据集中子集出现了几次
                   sscnt[can] = 1
                else:
                    sscnt[can] += 1
    numitems = float(len(d)) #计算数据集大小
    returnlist = []
    supportdata = {}
    for key in sscnt:
        support = sscnt[key]/numitems  #计算每个候选数据的支持度
        if support >= minsupport:
            returnlist.insert(0,key)  #在列表最前面加入
        supportdata[key] = support  #一定是要是一个子集才会列入频繁集字典中计算得分
    return returnlist,supportdata
dataset = loaddata()
#c1 = createc1(dataset)
#l1,supportdata0 = scand(list(map(set,dataset)),c1,0.5)
#————————————————————————————————————————————————————————————————————————————————————————
#完整APRIORI算法(用于寻找所有频繁集合)
def apriorigen(lk,k):  #输入为确定是频繁集的集合以及集合合并之后的长度
    returnlist = []
    lenlk = len(lk)
    for i in range(lenlk):   #高效的集合合并，从子集出发，构建出两两合并所有可能的超集
        for j in range(i+1,lenlk):
            l1 = list(lk[i])[:k-2]
            l2 = list(lk[j])[:k-2]
            l1.sort()
            l2.sort()
            if l1==l2:
                returnlist.append(lk[i]|lk[j])  #|表示集合的合并
    return returnlist
def apriori(dataset,minsupport = 0.5):
    c1 = createc1(dataset)
    d = list(map(set,dataset))
    l1,supportdata = scand(d,c1,minsupport)  #选择大于最小支持度的单个子集
    l = [l1]
    k = 2
    while (len(l[k-2])>0):  #最后合并的时候当合并到最大的时候无法合并的时候返回空集，就无法继续循环了
        ck = apriorigen(l[k-2],k)
        lk,supk = scand(d,ck,minsupport)  #空集输入的返回是两个空集合
        supportdata.update(supk)  #更新兴趣度集合(在里面加入新的元素)
        l.append(lk)
        k += 1
    return l,supportdata
#————————————————————————————————————————————————————————————————————————————————————————
#寻找关联规则(利用可信度来度量)  一条规则P--导致--H的可信度为support(P|H)/support(P)
#如果某一条关联规则没达到可信度要求，则左侧的集合的子集导出的关联规则也无法达到可信度要求
#基于频繁集来构建关联规则
def generaterules(L,supportdata,minconf = 0.7):
    bigrulelist = []
    for i in range(1,len(L)): #基于频繁集来生成规则，只有一个元素的频繁集无法生成规则，故从1开始
        for freqset in L[i]:
            H1 = [frozenset([item]) for item in freqset]  #将一个集合中的元素每个元素边一个集合存入列表中
            if (i>1):  #如果集合包含两个元素以上，有多种规则生成方式，需要额外进行集合合并
                rulefromconseq(freqset,H1,supportdata,bigrulelist,minconf)
            else:  #如果只有两个元素的集合，那么规则生成就直接放两边，直接计算得分
                calcconf(freqset,H1,supportdata,bigrulelist,minconf)
    return bigrulelist
def calcconf(freqset,H,supportdata,brl,minconf = 0.7):  #计算规则的可信度  
    prunedh = []   #freqset为包含同个数元素的集合集
    for conseq in H:  #计算freqset-conseq----conseq的置信度
        conf = supportdata[freqset]/supportdata[freqset - conseq]  #集合之间可以直接做减法
        if conf >= minconf:
            print(freqset-conseq,end = '')
            print('--->',end='')
            print(conseq,end = '')
            print('conf:',end='')
            print(conf)
            brl.append((freqset-conseq,conseq,conf))  #brl为规则集合，加入新的满足条件的规则,最后在主函数中返回
            prunedh.append(conseq)
    return prunedh  #返回满足条件的规则结果，因就是集合总体减去结果
def rulefromconseq(freqset,H,supportdata,brl,minconf = 0.7):
    m = len(H[0])  
    if (len(freqset)>(m+1)):  #如果集合长度大于m+1，即保证合并后一边的元素个数为m+1，另一边至少也能保留一个元素
        Hmp1 = apriorigen(H,m+1)  #进行集合合并
        Hmp1 = calcconf(freqset,Hmp1,supportdata,brl,minconf)  #返回得到的是满足置信条件的结果集合
        if len(Hmp1)>1:  #如果合并后集合个数大于1，则继续合并操作(递归，当然在之后执行之前也要先判断继续合并下去可否构成规则)
            rulefromconseq(freqset,Hmp1,supportdata,brl,minconf)
    return None
#L,supportdata = apriori(dataset,minsupport = 0.5)
#rules = generaterules(L,supportdata,minconf = 0.5)

mushdata = [line.split() for line in open('F:/机器学习实战/machinelearninginaction/Ch11/mushroom.dat','r')]
L,supportdata = apriori(mushdata,minsupport = 0.3)
for item in L[3]:
    if item.intersection('2'):
        print(item)

    
            



                    
