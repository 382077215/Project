'''此算法为简化版SMO算法，选择优化的alpha时并不是先选取违背KKT条件最大的，再选取使二次规划目标函数增幅最大的变量
选择方式为：遍历每一个alpha，然后在剩下的alpha中再随机选取一个alpha'''
import numpy as np
def loaddata(filename): #读取数据
    data = []
    label = []
    f = open(filename,'r')
    for line in f.readlines():
        temp = line.strip().split('\t')
        data.append([float(temp[0]),float(temp[1])])
        label.append(float(temp[2]))
    return data,label
def selectjrand(i,m):  #i为第一个alpha下标，m所有alpha个数
    while 1:
        j = int(np.random.uniform(0,m))
        if i != j:
            break
    return j
def controlalpha(aj,H,L): #用于控制alpha大于极端后的值(二次规划产生的范围，见李航P126c)
    if aj>H:
        aj = H
    if L>aj:
        aj = L
    return aj
def simplesmo(data,label,C,tol,maxiter):#数据集，标签，常数C(即软间隔常数，允许一部分样本不满足分类,控制软间隔(松弛变量)所占的比重，C越大越严格)，容错率(违反KKT条件的程度)，最大迭代次数
    datamat = np.mat(data)
    labelmat = np.mat(label).T
    m,n = np.shape(datamat)
    alphas = np.mat(np.zeros((m,1)))  #初始化alpha序列，全部先设为0,考虑到优化问题的约束条件
    b = 0; iternum= 0   #最终结果的常数b先设置为0
    while (iternum<maxiter):
        alphachanged = 0  #用于记录alpha是否已经被优化
        for i in range(m):
            fxi = float(np.multiply(alphas,labelmat).T*(datamat*datamat[i,:].T))+b  #先计算某个样本点的估计值,multiply为矩阵对应元素相乘,*为矩阵乘法
            ei = fxi - float(labelmat[i,:])  #计算估计误差，流程可见李航P127
            if ((labelmat[i,:]*ei<-tol) and (alphas[i]<C)) or ((labelmat[i,:]*ei>tol) and (0<alphas[i])):#检验KKT条件,如果违背的厉害，则需要优化，见李航P129,!!!!!!alphai优先选0到C之间的点!!!!!!                
                #边界上的点就算不满足KKT条件，在优化过程中也很难变化，然而非边界的却变化很大，最后退出要所有点均满足KKT
                #这里两个条件起始涵盖了KKT条件不满足时的三种情况  李航P129
                #一种是目标函数大于0，但是alpha应该等于0，但这里条件大于0了
                #一种是目标函数小于0，但是alpha应该等于C，但这里条件小于C了
                #一种是目标函数等于0，alpha在0到C之间(or两边均满足这个条件)，但这里目标函数却没有等于0的
                #这里只要控制alpha的一边取值范围就可以了，另外一边不用控制，因为最后一边最终肯定也会在[0,C]中，因为最后会在二次规划是限制alphaj的取值
                #第一次循环将会从or的左边满足判断随后进行值得更新
                j = selectjrand(i,m)   #选择第二个alpha，随机选择
                fxj = float(np.multiply(alphas,labelmat).T*(datamat*datamat[j,:].T))+b
                ej = fxj - float(labelmat[j,:])
                alphaiold = alphas[i].copy()  #很关键，对于矩阵对象，相当于拷贝值且重新分配一个内存，alphas变了但alphaiold不变
                alphajold = alphas[j].copy()
                if labelmat[j,:] != labelmat[i,:]:  #根据不同情况确定alphajnew的边界，李航P126
                    L = max(0,alphas[j]-alphas[i])
                    H = min(C,C+alphas[j]-alphas[i])
                else:
                    L = max(0,alphas[j]+alphas[i]-C)
                    H = min(C,alphas[j]+alphas[i])
                if L==H:   #如果下边界等于上边界，alphaj无法合适的使目标函数下降，就什么也不做，回到第一个循环，重新选取一个alphai
                    print('L==H')
                    continue
                eta = datamat[i,:]*datamat[i,:].T+datamat[j,:]*datamat[j,:].T-2*datamat[i,:]*datamat[j,:].T
                if eta<=0:   #此eta为二范数平方，一定大于0，如果小于等于0，后面无法计算，可能alphai选的不合适，重新循环选取
                    print('eta<=0')
                    continue
                alphas[j] = alphas[j]+labelmat[j]*(ei-ej)/eta
                alphas[j] = controlalpha(alphas[j],H,L)  #选择出合适的最优值，二次规划问题，李航P127
                if abs(alphas[j]-alphajold)<0.00001:  #alphaj变化量不够的话，保留alphaj这个值，但要重新再选取一遍alphai，也不对应的更新alphai的值
                    print('j not move enough')
                    continue
                alphas[i] = alphas[i] + labelmat[i]*labelmat[j]*(alphajold-alphas[j])
                b1 = b-ei-labelmat[i]*(datamat[i,:]*datamat[i,:].T)*(alphas[i]-alphaiold)-labelmat[j]*(datamat[j,:]*datamat[i,:].T)*(alphas[j]-alphajold)
                b2 = b-ej-labelmat[i]*(datamat[i,:]*datamat[j,:].T)*(alphas[i]-alphaiold)-labelmat[j]*(datamat[j,:]*datamat[j,:].T)*(alphas[j]-alphajold)
                if 0<alphas[i]<C:  #选取b的值，李航P130
                    b = b1
                elif 0<alphas[j]<C:
                    b = b2
                else:
                    b = (b1+b2)/2.0
                alphachanged += 1  #alpha参数已经经过一次优化
                print('iter: %d  i: %d  changednum: %d'%(iternum,i,alphachanged))  #优化之前迭代次数，修改的下标，参数优化次数
        if (alphachanged==0):  #如果有参数更新，迭代次数重新为0，所以停机条件一定是在数据集上遍历maxiter次且没有参数优化
            iternum += 1
        else:
            iternum = 0
        print('iter: %d'%iternum)
    return b,alphas
#测试---------------------------------------------------------------------------------------
'''data,label = loaddata('F:/机器学习实战/machinelearninginaction/Ch06/testSet.txt')
b,alphas = simplesmo(data,label,0.6,0.001,40)
w = np.multiply(alphas.T,np.mat(label))*np.mat(data)'''



