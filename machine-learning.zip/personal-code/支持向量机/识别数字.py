import numpy as np
from SMOKER import smok
from SMOKER import kernel
from os import listdir   #该函数可以读取指定目录下的所有文件名称
#将32*32的二进制图像转为1*1024的向量
def imgvector(filename):  #将图像文件转化为向量
    returnvect = np.zeros((1,1024))
    f = open(filename,'r')
    for i in range(32):
        line = f.readline()  #与readlines不同，一次只读一行，要自己循环往下读
        for j in range(32):
            returnvect[0,i*32+j] = int(line[j])
    return returnvect
def loadimages(dirname):
    numberlabel = []
    trainlist = listdir(dirname)
    m = len(trainlist)
    trainmat = np.zeros((m,1024))
    for i in range(m):
        filename = trainlist[i]
        filestr = filename.split('.')[0]
        classnumber = int(filestr.split('_')[0])
        if classnumber == 9:
            numberlabel.append(-1)
        else:
            numberlabel.append(1)
        trainmat[i,:] = imgvector(dirname+'/'+filename)
    return trainmat,numberlabel
def testnumber(ktup = ('rbf',10)):
    data,label = loadimages(dirname)
    b,alphas = smok(data,label,200,0.0001,10000,ktup)
    datamat = np.mat(data)
    labelmat = np.mat(label).T
    supportindex = np.nonzero(alphas.A>0)[0]
    supportvector = datamat[supportindex,:]
    supportlabel = labelmat[supportindex,:]
    m,n = np.shape(datamat)
    errorcount = 0
    for i in range(m):
        temp = kernel(supportvector,datamat[i,:],ktup)
        predict = np.multiply(alphas[supportindex,:],supportlabel).T*temp + b
        if float(np.sign(predict)) != float(np.sign(labelmat[i,:])):
            errorcount += 1
    print('supportvector number: %d'%np.shape(supportvector)[0])
    print('train error: %f'%(float(errorcount)/m))
    data,label = loadimages(dirname1)
    datamat = np.mat(data)
    labelmat = np.mat(label).T
    m,n = np.shape(datamat)
    errorcount = 0
    for i in range(m):
        temp = kernel(supportvector,datamat[i,:],ktup)
        predict = np.multiply(alphas[supportindex,:],supportlabel).T*temp + b
        if float(np.sign(predict)) != float(np.sign(labelmat[i,:])):
            errorcount += 1
    print('test error: %f'%(float(errorcount)/m))
dirname = 'F:/机器学习实战/machinelearninginaction/Ch06/trainingDigits'
dirname1 = 'F:/机器学习实战/machinelearninginaction/Ch06/testDigits'
testnumber(ktup=('rbf',10))



