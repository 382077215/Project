'''使用核技巧的完整版SMO算法'''
from simpleSMO import *  #导入自写模块
import numpy as np
def kernel(X,A,ktup):  #定义计算核矩阵的函数，ktup定义核函数的形式，为一个二元组，第一个为核函数类型，后面的核函数的一些参数
    #X为一个数据集，A为数据集的某一行(某一个样本)
    m,n = np.shape(X)
    K = np.mat(np.zeros((m,1)))   #核矩阵按一列一列来计算
    if ktup[0] == 'lin':
        K = X*A.T
    elif ktup[0] == 'rbf':  #高斯核
        for j in range(m):
            temp = X[j,:]-A
            K[j] = temp*temp.T
        K = np.exp(-K/2*(ktup[1]**2))
    else:
        raise NameError('kernel function is not defined')
    return K
class corestruct():    #利用一个数据结构来存储所有重要数据，省去手工输入
    def __init__(self,datamat,classlabel,C,toler,ktup):  #ktup定义核函数,形式是一个元组
        self.data = datamat
        self.label = classlabel
        self.C = C
        self.tol = toler
        self.m = np.shape(datamat)[0]
        self.alphas = np.mat(np.zeros((self.m,1)))
        self.b = 0
        self.error = np.mat(np.zeros((self.m,2))) #第一列记录是否有效，第二列记录实际误差值,有效表示对应的实际误差以及计算好了，1表示有效。这是一个误差缓存
        self.K = np.mat(np.zeros((self.m,self.m)))  #定义核矩阵
        for i in range(self.m):
            self.K[:,i] = kernel(self.data,self.data[i,:],ktup)
def ekc(cs,k):  #定义一个函数计算误差
    fxk = float(np.multiply(cs.alphas,cs.label).T*cs.K[:,k])+cs.b
    ek = fxk - float(cs.label[k,:])
    return ek
def selectj(i,cs,ei):  #选择alphaj
    maxk = -1  #设定初始值，即选取的j，最大增量以及alphaj的误差
    maxdelta = 0
    ej = 0
    cs.error[i] = [1,ei]   #首先将输入值ei设置为有效，即ei值已经计算好了
    validlist = np.nonzero(cs.error[:,0].A)[0]  #提取出error中第一列不为0的下标，即有效的下标,  .A表示转为数组
    if len(validlist)>1:   #非第一次循环的情况下，直接在有效值上寻找使得误差变化最大的下标j
        #直接在当前情况下的有效值上找(之前被用到过的alpha,如被更新过的alphaj，不满足KKT的alphai)，即这些alpha更可能对应支持向量，不用全局alpha找，从而节约时间
        for k in validlist:
            if k==i:  #下标不允许相同
                continue
            ek = ekc(cs,k)  #这里要重新计算ek的原因是在alpha值更新后，值更新了对应alpha的误差，但是表中别的有效的alpha值的误差也会相应变化，但没有被更新，因此重新算一下
            deltae = abs(ek-ei)
            if deltae>maxdelta:
                maxk = k
                maxdelta = deltae
                ej = ek
    else:    #如果只有一个有效误差值，即第一次循环，则alphaj就随机选取
        j = selectjrand(i,cs.m)
        ej = ekc(cs,j)
    return maxk,ej
def updateek(cs,k):#计算误差值并存入误差缓存之中
    ek = ekc(cs,k)
    cs.error[k] = [1,ek]
def innerselect(i,cs):  #alphaj选择的启发式算法
    ei = ekc(cs,i)  #计算alphai的误差
    if (cs.label[i]*ei<-cs.tol and cs.alphas[i]<cs.C) or (cs.label[i]*ei>cs.tol and cs.alphas[i]>0):  #检验alphai是否不满足KKT条件，不满足才会选取并再选取j
        j,ej = selectj(i,cs,ei)
        alphaiold = cs.alphas[i].copy()
        alphajold = cs.alphas[j].copy()
        if cs.label[i,:] != cs.label[j,:]:
            L = max(0,cs.alphas[j]-cs.alphas[i])
            H = min(cs.C,cs.C+cs.alphas[j]-cs.alphas[i])
        else:
            L = max(0,cs.alphas[j]+cs.alphas[i]-cs.C)
            H = min(cs.C,cs.alphas[j]+cs.alphas[i])
            if L==H:   #上下界一样，需要重新选取alphai
                print('L==H')
                return 0
        eta = cs.K[i,i]+cs.K[j,j]-2.0*cs.K[i,j]
        if eta<=0:
            print('eta<=0')
            return 0
        cs.alphas[j] += cs.label[j,:]*(ei-ej)/eta
        cs.alphas[j] =  controlalpha(cs.alphas[j],H,L)
        updateek(cs,j)  #选择了j之后，计算得到新的alphaj，将其对应的误差更新至缓存中
        if abs(cs.alphas[j]-alphajold)<0.00001:
            print('j not move enough')
            return 0
        cs.alphas[i] += cs.label[i]*cs.label[j]*(alphajold - cs.alphas[j])
        updateek(cs,i)  #计算得到新的alphai，将其对应的误差更新至缓存中
        b1 = cs.b - ei - cs.label[i]*(cs.alphas[i]-alphaiold)*cs.K[i,i]-cs.label[j]*(cs.alphas[j]-alphajold)*cs.K[i,j]
        b2 = cs.b - ej - cs.label[i]*(cs.alphas[i]-alphaiold)*cs.K[i,j]-cs.label[j]*(cs.alphas[j]-alphajold)*cs.K[j,j]
        if 0<cs.alphas[i]<cs.C:
            cs.b = b1
        elif 0<cs.alphas[j]<cs.C:
            cs.b = b2
        else:
            cs.b = (b1+b2)/2.0
        return 1   #只有alphai,alphaj这一对值都被改变了，才返回1
    else:  #若alphai满足KKT则返回0
        return 0
def smok(data,labels,C,toler,maxiter,ktup = ('lin',0)):  #加入核函数后的修改版高效SMO算法，默认采用线性核函数(即和原来一样)
    cs = corestruct(np.mat(data),np.mat(labels).T,C,toler,ktup)
    iternum = 0
    alphachange = 0
    entire = True  #记录是否在整个数据集上遍历还是只遍历非边界值即0与C之间的值
    while (iternum<maxiter and alphachange>0) or entire:
        alphachange = 0
        if entire:  #如果当前遍历需要在整个数据集上遍历
            for i in range(cs.m):
                alphachange += innerselect(i,cs)  #不但选择alphaj，更新alphai,alphaj，还记录更新这一对alpha更新了几次
                print('fulldata,iter: %d,i: %d,alphachange: %d'%(iternum,i,alphachange))
            iternum += 1
        else:   #遍历非边界值
            nonbound = np.nonzero((cs.alphas.A>0)*(cs.alphas.A<cs.C))[0]  #记录不在边界上的alpha的下标
            for i in nonbound:
                alphachange += innerselect(i,cs)
                print('non-bound,iter: %d,i: %d,alphachange: %d'%(iternum,i,alphachange))
            iternum += 1
        if entire:  #如果这一次在全部数据上遍历完，下一次就去非边界值上遍历
            entire = False
        elif alphachange==0:  #如果这一次没有一对alpha被修改，则下一次就要在全部数据上遍历，可以看到还是优先遍历非边界点
            entire = True
        print('iternumber: %d'%iternum)
    #可以看到停机条件为在整个数据集上遍历后依旧没有一对alpha被更新或者遍历完整个数据集之后，到达了最大迭代次数
    return cs.b,cs.alphas
#————————————————————————————————————测试样例——————————————————————————————————————————————
'''data,label = loaddata('F:/机器学习实战/machinelearninginaction/Ch06/testSet.txt')
b,alphas = smok(data,label,0.6,0.001,40)
w = np.multiply(alphas.T,np.mat(label))*np.mat(data)'''
#————————————————————————————————————测试样例——————————————————————————————————————————————

#————————————————————————————————————高斯核函数测试样例———————————————————————————————————————————
'''def testrbf(par = 1.3):
    data,label = loaddata('F:/机器学习实战/machinelearninginaction/Ch06/testSetRBF.txt')
    b,alphas = smok(data,label,200,0.0001,10000,('rbf',par))
    datamat = np.mat(data)   #转为矩阵形式方便之后计算
    labelmat = np.mat(label).T
    supportindex = np.nonzero(alphas.A>0)[0]   #因为拉格朗日乘子要求alpha均大于等于0，这里寻找支持向量下标
    supportvector = datamat[supportindex,:]
    supportlabel = labelmat[supportindex]
    m,n = np.shape(datamat)
    errorcount = 0
    for i in range(m):
        temp = kernel(supportvector,datamat[i,:],('rbf',par))
        predict = temp.T*np.multiply(alphas[supportindex],supportlabel)+b
        if float(np.sign(predict)) != float(np.sign(labelmat[i])):
            errorcount += 1
    print('support number: %d'%np.shape(supportvector)[0])
    print('traing error: %f'%(float(errorcount/m)))
    #数据测试
    data,label = loaddata('F:/机器学习实战/machinelearninginaction/Ch06/testSetRBF2.txt')
    errorcount = 0
    datamat = np.mat(data)   #转为矩阵形式方便之后计算
    labelmat = np.mat(label).T
    m,n = np.shape(datamat)
    for i in range(m):
        temp = kernel(supportvector,datamat[i,:],('rbf',par))
        predict = temp.T*np.multiply(alphas[supportindex],supportlabel)+b
        if float(np.sign(predict)) != float(np.sign(labelmat[i])):
            errorcount += 1
    print('testing error: %f'%(float(errorcount/m)))
testrbf()'''
#————————————————————————————————————高斯核函数测试样例———————————————————————————————————————————

        
        
            
    
